created = [[2019-26-04T00:00:00+00:00]]
title = [[TTS for Cities of MDhoria]]
version = [[1]]
author = [[xanthia]]
mpackage = [[tts-for-cities-of-mdhoria]]
description = [[This is a UI package that includes text-to-speech support for accessibility on Cities Of M'Dhoria, with graphic bars for player and enemy and a working auto-mapper (which just require some walking rules/discipline).

---
This package was originally shared on the [Mudlet Forums](https://forums.mudlet.org/viewtopic.php?f=6&t=22736&sid=f8b58b442e976180e3f6220553eccb8e) by the author. We’ve automatically listed it here on packages.mudlet.org so more users can discover and benefit from it. Please let us know if you have any questions or concerns - thanks for contributing to the Mudlet community!]]


